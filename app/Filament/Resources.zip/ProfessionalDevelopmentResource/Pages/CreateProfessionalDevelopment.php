<?php

namespace App\Filament\Resources\ProfessionalDevelopmentResource\Pages;

use App\Filament\Resources\ProfessionalDevelopmentResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateProfessionalDevelopment extends CreateRecord
{
    protected static string $resource = ProfessionalDevelopmentResource::class;
}
