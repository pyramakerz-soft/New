<?php

namespace App\Filament\Resources\LessonPlanResource\Pages;

use App\Filament\Resources\LessonPlanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateLessonPlan extends CreateRecord
{
    protected static string $resource = LessonPlanResource::class;
}
