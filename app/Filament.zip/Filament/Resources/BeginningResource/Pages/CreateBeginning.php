<?php

namespace App\Filament\Resources\BeginningResource\Pages;

use App\Filament\Resources\BeginningResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateBeginning extends CreateRecord
{
    protected static string $resource = BeginningResource::class;
}
