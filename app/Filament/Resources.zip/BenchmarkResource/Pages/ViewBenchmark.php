<?php

namespace App\Filament\Resources\BenchmarkResource\Pages;

use App\Filament\Resources\BenchmarkResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewBenchmark extends ViewRecord
{
    protected static string $resource = BenchmarkResource::class;
}
