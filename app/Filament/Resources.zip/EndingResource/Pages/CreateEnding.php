<?php

namespace App\Filament\Resources\EndingResource\Pages;

use App\Filament\Resources\EndingResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateEnding extends CreateRecord
{
    protected static string $resource = EndingResource::class;
}
